#version 330

#moj_import <minecraft:fog.glsl>
#moj_import <minecraft:dynamictransforms.glsl>

uniform sampler2D Sampler0;

in float sphericalVertexDistance;
in float cylindricalVertexDistance;
in vec4 vertexColor;
in vec2 texCoord0;
in vec2 texCoord1;

out vec4 fragColor;

// quack
vec4 computeCustomFog(vec4 baseColor, float sDist, float cDist) {
    float fEnv = smoothstep(FogEnvironmentalStart, FogEnvironmentalEnd, sDist);
    float fRender = smoothstep(FogRenderDistanceStart, FogRenderDistanceEnd, cDist);
    float factor = clamp(max(fEnv, fRender), 0.0, 1.0);
    
    return vec4(mix(baseColor.rgb, FogColor.rgb, factor * FogColor.a), baseColor.a);
}

void main() {
    vec4 textureSample = texture(Sampler0, texCoord0);
    vec4 litColor = textureSample * vertexColor * ColorModulator;

    // Descarte antecipado (Alpha Test)
    if (litColor.a < 0.1) discard;

    // Normaliza o alpha para escala 0-255 para verificações específicas
    int alphaInt = int(round(litColor.a * 255.0));
    
    // Lógica de "bypass" ou modificação baseada no Alpha
    // 253, 252: Ignora iluminação do vértice (mantém apenas textura e modulador)
    // 251, 250: Aplica multiplicadores de escurecimento (0.75 e 0.5)
    if (alphaInt >= 250 && alphaInt <= 253) {
        vec4 modifiedColor = textureSample * ColorModulator;
        modifiedColor.a = litColor.a;

        if (alphaInt == 251) modifiedColor.rgb *= 0.75;
        if (alphaInt == 250) modifiedColor.rgb *= 0.5;

        fragColor = modifiedColor;
        return;
    }

    // Comportamento padrão com fog
    fragColor = computeCustomFog(litColor, sphericalVertexDistance, cylindricalVertexDistance);
}