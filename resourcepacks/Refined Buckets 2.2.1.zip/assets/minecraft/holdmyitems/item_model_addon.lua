global.yawAngle = 0;
global.yawAngleO = 0;
global.pitchAngle = 0;
global.pitchAngleO = 0;
global.fall = 0;
global.a = 0;
global.walk = 0;
global.walkSmoother = 0;
global.fall_f = 0;
global.jiggle_f = 0;
global.mainHandSwitch = 0;
global.offHandSwitch = 0;
global.jiggle_i = 0.0;

local lb = (context.bl and 1) or -1
local player = context.player
local item = context.item
local matrices = context.matrices
local mainHand = context.mainHand

local l = data.bl and 1 or -1
jiggle_i = jiggle_i + P:getYSpeed(data.player) * data.deltaTime * 30
if not P:isOnGround(data.player) and P:getYSpeed(data.player) * -1 > 0.55 then
    fall_f = fall_f + 0.045 * data.deltaTime * 30;
else
    fall_f = fall_f - 0.07 * data.deltaTime * 30
end
fall_f = M:clamp(fall_f, 0, 1)
local wf = M:clamp(fall * 0.4, 0, 2) * (fall_f * fall_f * fall_f)
local l = data.bl and 1 or -1
local safeFall = M:clamp(fall, 0, 4)
local ptAngle = (mainHand and pitchAngle) or pitchAngleO
local ywAngle = (mainHand and yawAngle) or yawAngleO

local buckets = {
    "minecraft:bucket",
    "minecraft:water_bucket",
    "minecraft:lava_bucket",
    "minecraft:milk_bucket",
    "minecraft:powder_snow_bucket",
    "minecraft:cod_bucket",
    "minecraft:salmon_bucket",
    "minecraft:tropical_fish_bucket",
    "minecraft:tadpole_bucket",

}

if I:isOf(data.item, Items:get("minecraft:water_bucket")) or I:isOf(data.item, Items:get("minecraft:lava_bucket")) or I:isOf(data.item, Items:get("minecraft:milk_bucket")) and not (P:isUsingItem(player)) then
    animator:rotateX(0, 1, M:clamp(-ptAngle * 0.9, -5, 5), 0.5, 0.9, 0.5)
    animator:rotateZ(0, 1, M:clamp(ywAngle * 0.9, -5, 5) , 0.5, 0.9, 0.5)
end

if I:isOf(data.item, Items:get("minecraft:axolotl_bucket")) then
    animator:moveY(0, 11, fall * 0.02)
    animator:moveY(0, 11, 0.02 * math.sin(a * -1.5)  * (1-walkSmoother))
    animator:moveY(0, 11,  0.08 * Easings:easeInSine(math.abs(math.sin(walk))) * walkSmoother)
    animator:rotateX(0, 11, M:clamp(20 * fall, -20, 20), 0.5, 0.7, 0.5)
    animator:rotateZ(0, 11, 2 * math.sin(a), 0.5, 0.7, 0.5)
    animator:rotateX(0, 11, ptAngle * 0.3, 0.5, 0.7, 0.5)
    animator:rotateZ(0, 11, -ywAngle * 0.3 , 0.5, 0.7, 0.5)

    animator:moveY(12, 19, 0.02 * math.sin(a * -1.5) * (1-walkSmoother))
    animator:moveY(12, 19, 0.08 * Easings:easeInSine(math.abs(math.sin(walk))) * walkSmoother)
    animator:rotateX(12, 19, M:clamp(15 * fall, -20, 20), 0.5, 0.7, 0.5)
    animator:rotateZ(12, 19, 1 * math.sin(a), 0.5, 0.7, 0.5)
    animator:rotateX(12, 19, ptAngle * 0.15, 0.5, 0.7, 0.5)
    animator:rotateZ(12, 19, -ywAngle * 0.15 , 0.5, 0.7, 0.5)

    animator:rotateY(8, 9, 10 * math.sin(a * 10) * M:pow(math.sin(a * 0.4), 30), 0.8, 0.5, 0.4)
    animator:rotateY(10, 11, -10 * math.sin(a * 10) * M:pow(math.sin(a * 0.4), 30), 0.3, 0.5, 0.4)
    animator:rotateX(20, 21, 80 * wf, 0.5, 0.85, 0.3)
    animator:rotateZ(20, 21, 15 * wf, 0.5, 0.85, 0.3)
    animator:rotateX(22, 23, 80 * wf, 0.5, 0.85, 0.3)
    animator:rotateZ(22, 23, -15 * wf, 0.5, 0.85, 0.3)

    animator:moveX(0, 23, fall * 0.02)
    animator:moveZ(0, 23, fall * 0.025)
    animator:scale(0, 23,  1 - (0.03 * fall), 1 + (0.03 * fall), 1 - (0.03 * fall))


end

if I:isOf(data.item, Items:get("minecraft:pufferfish_bucket")) then

    animator:moveY(0, 29, fall * 0.1)
    animator:moveY(0, 29, 0.02 * math.sin(a * -1.5)  * (1-walkSmoother))
    animator:moveY(0, 29, 0.08 * Easings:easeInSine(math.abs(math.sin(walk))) * walkSmoother)
    animator:moveZ(0, 29, 0.1)
    animator:moveY(0, 29, -0.03)
    animator:moveY(0, 29, (-ywAngle * 0.002) )
    animator:rotateY(0, 29, -ywAngle * 0.2, 0.5, 0.5, 0.5)
    animator:rotateX(0, 29, -ptAngle * 0.2, 0.5, 0.5, 0.5)
    animator:rotateZ(0, 29, -ywAngle * 0.2, 0.5, 0.5, 0.5)
    animator:rotateX(0, 29, 1 * math.sin(a * 3)  * (1-walkSmoother), 0.5, 0.5, 0.5)

    animator:rotateZ(6, 7, 10 * math.sin(a * 10) * M:pow(math.sin(a * 0.4), 30), 0.5, 0.5, 0.5)
    animator:rotateZ(8, 9, -10 * math.sin(a * 10) * M:pow(math.sin(a * 0.4), 30), 0.5, 0.5, 0.5)
    
end


if I:isOf(data.item, Items:get("minecraft:tropical_fish_bucket")) then
    animator:moveY(0, 13, safeFall * 0.02)
    animator:moveY(0, 13, 0.02 * math.sin(a * -1.5)  * (1-walkSmoother))
    animator:moveY(0, 13, 0.08 * Easings:easeInSine(math.abs(math.sin(walk))) * walkSmoother)
    animator:moveZ(0, 13, 0.1)
    animator:moveY(0, 13, -0.03)
    animator:moveY(0, 13, -ywAngle * 0.002)
    animator:rotateX(0, 13, -ywAngle , 0.5, 0.5, 0.5)
    animator:rotateZ(0, 13, ptAngle , 0.5, 0.5 , 0.5)
    animator:rotateX(0, 13, 3 * math.sin(a * 3)  * (1-walkSmoother), 0.5, 0.5, 0.5)

    animator:rotateZ(6, 7, 10 * math.sin(a * 1.5)  * (1-walkSmoother) , 0.5, 0.5, 0.5)
    animator:rotateZ(8, 9, 10 * -math.sin(a * 1.5)  * (1-walkSmoother) , 0.5, 0.5, 0.5)
    animator:moveX(6, 7, -0.02)
    animator:moveX(8, 9, 0.02)

    animator:rotateX(14, 15, M:clamp(-ptAngle * 0.9, -5, 5), 0.5, 0.9, 0.5)
    animator:rotateZ(14, 15, M:clamp(ywAngle * 0.9, -5, 5) , 0.5, 0.9, 0.5)

end

if I:isOf(data.item, Items:get("minecraft:salmon_bucket")) then
    animator:scale(0, 19, 0.9, 0.9, 0.9)
    animator:moveY(0, 19, safeFall * 0.1)
    animator:moveY(0, 19, 0.05)
    animator:moveY(0, 19, 0.02 * math.sin(a * -1.5)  * (1-walkSmoother))
    animator:moveY(0, 11, 0.05 * Easings:easeInSine(math.abs(math.sin(walk))) * walkSmoother)
    animator:moveY(12, 19, -0.05 * Easings:easeInSine(math.abs(math.sin(walk))) * walkSmoother)
    animator:moveZ(0, 19, 0.08)
    animator:moveX(0, 19, 0.08 )
    animator:moveY(0, 19, (-ywAngle * 0.002) )
    animator:rotateX(0, 19, ywAngle * 0.6  , 0.5, 0.5, 0.5)
    animator:rotateZ(0, 19, -ptAngle * 0.6  , 0.5, 0.5, 0.5)
    animator:rotateX(0, 19, 3 * math.sin(a * 1.5)  * (1-walkSmoother) , 0.5, 0.5, 0.5)
    animator:rotateX(0, 11, safeFall * -10 , 0.5, 0.5, 0.5)
    animator:rotateX(12, 19, safeFall * 10 , 0.5, 0.5, 0.5)
    animator:rotateX(41, 41, M:clamp(-ptAngle * 0.9, -5, 5), 0.5, 0.9, 0.5)
    animator:rotateZ(41, 41, M:clamp(ywAngle * 0.9, -5, 5) , 0.5, 0.9, 0.5)

    animator:rotateZ(18, 19, 8 * math.sin(a * 1.5)  * (1-walkSmoother) , 0.5, 0.5, 0.5)
    animator:moveZ(18, 19, -0.05)
  
    animator:rotateX(0, 5, 5 * math.sin(a * 1.5)  * (1-walkSmoother) , 0.5, 0.5, 0.5)

end

if I:isOf(data.item, Items:get("minecraft:tadpole_bucket")) then
    animator:moveY(0, 7, safeFall * 0.05)
    animator:moveY(0, 7, 0.02 * math.sin(a * -1.5)  * (1-walkSmoother))
    animator:moveY(0, 7, 0.08 * Easings:easeInSine(math.abs(math.sin(walk))) * walkSmoother)
    animator:moveZ(0, 7, 0.1)
    animator:moveY(0, 7, -0.03)
    animator:moveY(0, 7, (-ywAngle * 0.002) )
    animator:rotateY(0, 7, ywAngle * 0.6  , 0.5, 0.5, 0.5)
    animator:rotateX(0, 7, -ptAngle * 0.6 , 0.5, 0.5, 0.5)
    animator:rotateZ(0, 7, -ywAngle * 0.6  , 0.5, 0.5, 0.5)
    animator:rotateX(0, 7, 3 * math.sin(a * 3)  * (1-walkSmoother), 0.5, 0.5, 0.5)

    animator:rotateX(8, 9, M:clamp(-ptAngle * 0.9, -5, 5), 0.5, 0.9, 0.5)
    animator:rotateZ(8, 9, M:clamp(ywAngle * 0.9, -5, 5) , 0.5, 0.9, 0.5)

end

if I:isOf(data.item, Items:get("minecraft:cod_bucket")) then
    --Body parts
    animator:scale(0, 25, 0.9, 0.9, 0.9)
    animator:moveY(0, 25, safeFall * 0.1)
    animator:moveY(0, 25, 0.05)
    animator:moveY(0, 25, 0.02 * math.sin(a * -1.5)  * (1-walkSmoother))
    animator:moveY(0, 25, -0.05 * Easings:easeInSine(math.abs(math.sin(walk))) * walkSmoother)
    animator:moveZ(0, 25, 0.1)
    animator:moveY(0, 25, -0.03)
    animator:moveY(0, 25, (-ywAngle * 0.002) )
    animator:rotateX(0, 25, ywAngle * 0.6 , 0.5, 0.5, 0.5)
    animator:rotateZ(0, 25, ptAngle * 0.6  , 0.5, 0.5, 0.5)
    animator:rotateX(0, 25, 3 * math.sin(a * 1.5)  * (1-walkSmoother), 0.5, 0.5, 0.5)
    animator:rotateX(0, 25, safeFall * -10, 0.5, 0.5, 0.5)
    animator:moveX(0, 25, 0.15)
    animator:moveZ(24, 25, 0.05)
    animator:moveY(24, 25, 0.1)
    
    animator:rotateX(47, 47, M:clamp(-ptAngle * 0.9, -5, 5), 0.5, 0.9, 0.5)
    animator:rotateZ(47, 47, M:clamp(ywAngle * 0.9, -5, 5) , 0.5, 0.9, 0.5)

end

