global.axolotl_anim = 0.001;
global.pufferfish_anim = 0.001;
global.salmon_anim = 0.001;
global.cod_anim = 0.001;
global.tadpole_anim = 0.001;
global.liquid_anim = 0.001;
global.tropical_fish_anim = 0.001;

local lb = (context.bl and 1) or -1
local player = context.player
local item = context.item
local matrices = context.matrices
local mainHand = context.mainHand

global.yawAngle = 0;
global.yawAngleO = 0;
global.pitchAngle = 0;
global.pitchAngleO = 0;

local ptAngle = (mainHand and pitchAngle) or pitchAngleO
local ywAngle = (mainHand and yawAngle) or yawAngleO

local buckets = {
    "minecraft:bucket",
    "minecraft:water_bucket",
    "minecraft:lava_bucket",
    "minecraft:powder_snow_bucket",
    "minecraft:cod_bucket",
    "minecraft:salmon_bucket",
    "minecraft:tropical_fish_bucket",
    "minecraft:tadpole_bucket"

}

for _, feesh in ipairs(buckets) do
    if I:isOf(item, Items:get(feesh))
then
        M:moveY(matrices, 0.15)
        M:rotateY(matrices, 0)
        M:moveZ(matrices, -0.25)
        M:moveX(matrices, -0.06 *lb)
        M:rotateZ(matrices, 20 * lb)
        M:rotateX(matrices, 20)
        M:rotateX(matrices, M:clamp(P:getPitch(context.player) / -2.5, -20, 90) - ptAngle + ywAngle * 0.5, 0, -0.05, 0)
        return
    end
end

if I:isOf(item, Items:get("minecraft:milk_bucket")) then
    if P:isUsingItem(player) then
        -- Quando ESTIVER usando (Beber)
        M:rotateY(matrices, 10 * lb)
        M:rotateX(matrices, 0)
        M:rotateZ(matrices, 180)
        M:moveZ(matrices, -0.1)
        M:moveY(matrices, -0.3)
    else
        -- Quando NÃO estiver usando (Mesma posição dos outros baldes)
        M:moveY(matrices, 0.15)
        M:rotateY(matrices, 0)
        M:moveZ(matrices, -0.25)
        M:moveX(matrices, -0.06 * lb)
        M:rotateZ(matrices, 20 * lb)
        M:rotateX(matrices, 20)
        M:rotateX(matrices, M:clamp(P:getPitch(context.player) / -2.5, -20, 90) - ptAngle + ywAngle * 0.5, 0, -0.05, 0)
    end
    return
end

if I:isOf(item, Items:get("minecraft:axolotl_bucket")) or I:isOf(item, Items:get("minecraft:pufferfish_bucket")) then
M:moveY(matrices, 0.2)
M:rotateY(matrices, -0 * lb)
M:moveX(matrices, 0.1 * lb)
M:rotateX(matrices, 40)
    return
end

if I:isOf(item, Items:get("bucket_of_frog:frog_bucket_warm")) or I:isOf(item, Items:get("bucket_of_frog:frog_bucket_cold")) or I:isOf(item, Items:get("bucket_of_frog:frog_bucket_temperate"))then
M:moveY(matrices, 0.2)
M:rotateY(matrices, -0 * lb)
M:moveX(matrices, 0.12 * lb)
M:rotateX(matrices, 35)
    return
end

if I:isOf(context.item, Items:get("minecraft:lava_bucket")) then
particleManager:addParticle(
context.particles,
false,
-0.05 * l,
0.05,
0,
0,
0,
0,
0,
0,
0,
0,
0,
0,
2.0,
Texture:of("minecraft", "textures/particle/laranja.png"),
"ITEM",
context.hand,
"SPAWN",
"ADDITIVE",
0,
150 + (20 * M:sin(P:getAge(context.player) * 0.2))
)
end
