#version 330

#moj_import <minecraft:fog.glsl>

uniform sampler2D Sampler0;
uniform vec4 ColorModulator;
uniform float FogEnvironmentalStart;
uniform float FogEnvironmentalEnd;
uniform float FogRenderDistanceStart;
uniform float FogRenderDistanceEnd;
uniform vec4 FogColor;

in float sphericalVertexDistance;
in float cylindricalVertexDistance;
in vec4 vertexColor;
in vec2 texCoord0;
in vec2 texCoord1;

out vec4 fragColor;

vec4 computeCustomFog(vec4 baseColor, float sDist, float cDist) {
    float fEnv = smoothstep(FogEnvironmentalStart, FogEnvironmentalEnd, sDist);
    float fRender = smoothstep(FogRenderDistanceStart, FogRenderDistanceEnd, cDist);
    float factor = clamp(max(fEnv, fRender), 0.0, 1.0);
    
    return vec4(mix(baseColor.rgb, FogColor.rgb, factor * FogColor.a), baseColor.a);
}

void main() {
    vec4 textureSample = texture(Sampler0, texCoord0);
    vec4 litColor = textureSample * vertexColor * ColorModulator;

    if (litColor.a < 0.1) discard;

    int alphaInt = int(round(litColor.a * 255.0));

    // Lógica de bypass (250-253)
    if (alphaInt >= 250 && alphaInt <= 253) {
        vec4 modifiedColor = textureSample * ColorModulator;
        modifiedColor.a = litColor.a;

        if (alphaInt == 251) modifiedColor.rgb *= 0.75;
        if (alphaInt == 250) modifiedColor.rgb *= 0.5;

        fragColor = modifiedColor;
        return;
    }

    fragColor = computeCustomFog(litColor, sphericalVertexDistance, cylindricalVertexDistance);
}