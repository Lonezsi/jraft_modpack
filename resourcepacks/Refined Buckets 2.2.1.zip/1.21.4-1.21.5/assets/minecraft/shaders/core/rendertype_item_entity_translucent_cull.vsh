#version 330

#moj_import <minecraft:light.glsl>
#moj_import <minecraft:fog.glsl>
#moj_import <minecraft:projection.glsl>

in vec3 Position;
in vec4 Color;
in vec2 UV0;
in vec2 UV1;
in ivec2 UV2;
in vec3 Normal;

uniform mat4 ModelViewMat;
uniform mat4 ProjMat;
uniform vec3 Light0_Direction;
uniform vec3 Light1_Direction;
uniform sampler2D Sampler2;

out float sphericalVertexDistance;
out float cylindricalVertexDistance;
out vec4 vertexColor;
out vec2 texCoord0;
out vec2 texCoord1;
out vec2 texCoord2;

void main() {
    // Na 1.21.4, garantir que as matrizes estão declaradas como uniform é vital
    gl_Position = ProjMat * ModelViewMat * vec4(Position, 1.0);

    sphericalVertexDistance = length((ModelViewMat * vec4(Position, 1.0)).xyz);
    cylindricalVertexDistance = length((ModelViewMat * vec4(Position, 1.0)).xy);

    vec4 lightMapColor = texelFetch(Sampler2, UV2 / 16, 0); 
    vertexColor = minecraft_mix_light(Light0_Direction, Light1_Direction, Normal, Color) * lightMapColor;

    texCoord0 = UV0;
    texCoord1 = UV1;
    texCoord2 = vec2(UV2);
}