
-- Cyber was here :3

local l = context.bl and 1 or -1
local matrices = context.matrices
local item = context.item

-- Seeds
if (
    I:isOf(item, Items:get("minecraft:wheat_seeds")) or
    I:isOf(item, Items:get("minecraft:pumpkin_seeds")) or
    I:isOf(item, Items:get("minecraft:melon_seeds")) or
    I:isOf(item, Items:get("minecraft:beetroot_seeds")) or
    I:isOf(item, Items:get("minecraft:torchflower_seeds"))
) then
    M:moveY(matrices, 0.2)
    M:moveX(matrices, -0.05 * l)
    M:moveZ(matrices, 0.1)

    M:rotateY(matrices, 135 * l)
    M:rotateX(matrices, -45)
    M:rotateZ(matrices, 0 * l)

    M:scale(matrices, 0.85, 0.85, 0.85)
end